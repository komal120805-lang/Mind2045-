
# Mind2045 Video AI – Web App Starter

Use this repository to deploy your shallow app quickly.

## Deploy to Netlify
1. Sign up / log in to Netlify.
2. Fork this repo to your own GitHub.
3. In Netlify, click **Add new site → Import an existing project**.
4. Select your repo. Set build command (none) & publish dir `.`.
5. Deploy. Your site will be live in 1–2 minutes.

## Convert to Android APK
Use any WebView wrapper (PWA2APK, WebViewGold, Android Studio).
Point the WebView to your Netlify URL. Build & sign your APK.
